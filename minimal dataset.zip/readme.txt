Description:
This dataset provides the minimal raw data and scripts supporting the key findings in our manuscript.

Content:
The ground-anchor localization simulation folder contains the script files implementing the ground-anchor localization simulation algorithm.
The integrated flight experiments data folder contains the raw tension sensor data from the integrated flight experiments.
The static tilt experiment data.txt file contains the raw IMU tilt angle data from the static tilt experiment.